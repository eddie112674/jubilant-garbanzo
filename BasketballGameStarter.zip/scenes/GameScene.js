
import Phaser from 'phaser';

export default class GameScene extends Phaser.Scene {
    constructor() {
        super('GameScene');
    }

    preload() {
        this.load.image('court', 'assets/ui/court.png');
        this.load.image('player', 'assets/characters/player1.png');
        this.load.image('ball', 'assets/ui/ball.png');
    }

    create() {
        this.add.image(400, 300, 'court');

        this.player = this.physics.add.sprite(400, 500, 'player');
        this.ball = this.physics.add.sprite(400, 480, 'ball');
        this.ball.setCollideWorldBounds(true);
        this.ball.setBounce(0.8);

        this.input.on('pointerdown', this.shootBall, this);
        this.aimLine = this.add.graphics();
    }

    update() {
        const cursors = this.input.keyboard.createCursorKeys();

        if (cursors.left.isDown) this.player.setVelocityX(-200);
        else if (cursors.right.isDown) this.player.setVelocityX(200);
        else this.player.setVelocityX(0);

        this.aimLine.clear();
        this.aimLine.lineStyle(2, 0xffd700);
        this.aimLine.beginPath();
        this.aimLine.moveTo(this.ball.x, this.ball.y);
        this.aimLine.lineTo(this.input.activePointer.worldX, this.input.activePointer.worldY);
        this.aimLine.strokePath();
    }

    shootBall(pointer) {
        const angle = Phaser.Math.Angle.Between(this.ball.x, this.ball.y, pointer.worldX, pointer.worldY);
        const force = 500;
        this.ball.setVelocity(Math.cos(angle) * force, Math.sin(angle) * force);
    }
}
