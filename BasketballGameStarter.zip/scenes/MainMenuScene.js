
import Phaser from 'phaser';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';

export default class MainMenuScene extends Phaser.Scene {
    constructor() {
        super('MainMenuScene');
    }

    preload() {
        this.load.image('bg', 'assets/ui/menu-bg.png');
        this.load.image('button', 'assets/ui/button.png');
    }

    create() {
        this.add.image(400, 300, 'bg');
        this.add.text(300, 100, '🏀 Basketball Game', { fontSize: '28px', fill: '#fff' });

        this.nameInput = this.add.dom(400, 200, 'input', 'font-size: 20px; width: 200px', 'Player123');
        this.nameText = this.add.text(290, 170, 'Enter Name:', { fill: '#fff' });

        this.createButton('Login', 400, 260, () => this.handleLogin());
        this.createButton('Play Game', 400, 340, () => this.scene.start('LobbyScene'));
        this.createButton('Inventory', 400, 390, () => this.scene.start('InventoryScene'));
        this.createButton('Shop', 400, 440, () => this.scene.start('ShopScene'));
        this.createButton('Settings', 400, 490, () => this.scene.start('SettingsScene'));
    }

    createButton(text, x, y, callback) {
        let btn = this.add.image(x, y, 'button').setInteractive().setScale(1.5);
        let label = this.add.text(x - 40, y - 12, text, { fontSize: '16px', fill: '#000' });
        btn.on('pointerdown', callback);
    }

    handleLogin() {
        const email = this.nameInput.node.value + '@example.com';
        const password = 'basketball123';

        const auth = getAuth();
        signInWithEmailAndPassword(auth, email, password)
            .then(() => console.log('Logged in:', email))
            .catch(() =>
                createUserWithEmailAndPassword(auth, email, password)
                    .then(() => console.log('New user created:', email))
                    .catch(err => console.error(err))
            );
    }
}
