import { initializeFirebase, saveProgress, loadProgress } from './utils/firebase.js';
import MainMenu from './scenes/MainMenuScene.js';
import GameScene from './scenes/GameScene.js';
import GameOver from './scenes/GameOverScene.js';
import ProfileScene from './scenes/ProfileScene.js';
import ShopScene from './scenes/ShopScene.js';
import CharacterSelectScene from './scenes/CharacterSelectScene.js';

await initializeFirebase();
await loadProgress();

const config = {
  type: Phaser.AUTO,
  width: 800,
  height: 600,
  backgroundColor: '#222',
  parent: 'game-container',
  scene: [CharacterSelectScene, MainMenu, GameScene, GameOver, ShopScene, ProfileScene],
  physics: {
    default: 'arcade',
    arcade: { gravity: { y: 900 }, debug: false }
  }
};

new Phaser.Game(config);
