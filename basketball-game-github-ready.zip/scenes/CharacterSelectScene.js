// CharacterSelectScene.js
export default class CharacterSelectScene extends Phaser.Scene {
  constructor() {
    super('CharacterSelectScene');
  }

  create() {
    this.add.text(100, 100, 'CharacterSelectScene.js placeholder', { fontSize: '24px', fill: '#fff' });
  }
}
