// MainMenuScene.js
export default class MainMenuScene extends Phaser.Scene {
  constructor() {
    super('MainMenuScene');
  }

  create() {
    this.add.text(100, 100, 'MainMenuScene.js placeholder', { fontSize: '24px', fill: '#fff' });
  }
}
