// ShopScene.js
export default class ShopScene extends Phaser.Scene {
  constructor() {
    super('ShopScene');
  }

  create() {
    this.add.text(100, 100, 'ShopScene.js placeholder', { fontSize: '24px', fill: '#fff' });
  }
}
