// ProfileScene.js
export default class ProfileScene extends Phaser.Scene {
  constructor() {
    super('ProfileScene');
  }

  create() {
    this.add.text(100, 100, 'ProfileScene.js placeholder', { fontSize: '24px', fill: '#fff' });
  }
}
