// GameScene.js
export default class GameScene extends Phaser.Scene {
  constructor() {
    super('GameScene');
  }

  create() {
    this.add.text(100, 100, 'GameScene.js placeholder', { fontSize: '24px', fill: '#fff' });
  }
}
