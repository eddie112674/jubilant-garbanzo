// GameOverScene.js
export default class GameOverScene extends Phaser.Scene {
  constructor() {
    super('GameOverScene');
  }

  create() {
    this.add.text(100, 100, 'GameOverScene.js placeholder', { fontSize: '24px', fill: '#fff' });
  }
}
