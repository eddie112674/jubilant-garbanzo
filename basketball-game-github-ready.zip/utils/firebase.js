let db, uid;

export async function initializeFirebase() {
  const config = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT.appspot.com",
    messagingSenderId: "SENDER_ID",
    appId: "APP_ID"
  };
  firebase.initializeApp(config);

  await firebase.auth().signInAnonymously();
  uid = firebase.auth().currentUser.uid;
  db = firebase.firestore();
}

export async function loadProgress() {
  const doc = await db.collection('players').doc(uid).get();
  const data = doc.exists ? doc.data() : {};

  localStorage.setItem('xp', data.xp || 0);
  localStorage.setItem('coins', data.coins || 0);
  localStorage.setItem('unlocked', JSON.stringify(data.unlocked || ['player_red']));
  localStorage.setItem('selectedCharacter', data.selectedCharacter || 'player_red');
  localStorage.setItem('lastLogin', data.lastLogin || '');
}

export function saveProgress() {
  const xp = parseInt(localStorage.getItem('xp') || '0');
  const coins = parseInt(localStorage.getItem('coins') || '0');
  const unlocked = JSON.parse(localStorage.getItem('unlocked') || '[]');
  const selectedCharacter = localStorage.getItem('selectedCharacter');
  const lastLogin = localStorage.getItem('lastLogin');

  return db.collection('players').doc(uid).set({
    xp, coins, unlocked, selectedCharacter, lastLogin
  });
}
